# Stamp border

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshwcomeau/pen/VwRqQGP](https://codepen.io/joshwcomeau/pen/VwRqQGP).

